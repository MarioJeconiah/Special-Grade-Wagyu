import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

export default function Post({ posts, user, setPosts }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const post = posts.find(p => p.id.toString() === id);

  const [commentText, setCommentText] = useState("");

  if (!post) {
    return (
      <main className="content-container">
        <div className="content-box">
          <h2>Post Not Found</h2>
          <p>The discussion post you are looking for does not exist.</p>
          <button className="tierlist-btn" onClick={() => navigate('/forum')}>
            Go to Forum
          </button>
        </div>
      </main>
    );
  }

  // Handle Comment Submission
  const handleCommentSubmit = (e) => {
    e.preventDefault();

    if (!user) {
      alert("You must be logged in to comment.");
      return;
    }

    if (commentText.trim() === "") {
      return; // Do nothing if comment is empty
    }

    const newComment = {
      id: Date.now(), // Simple unique ID
      author: user.username,
      text: commentText.trim(),
      date: new Date().toLocaleDateString()
    };

    // Update the posts array with the new comment
    const updatedPosts = posts.map(p =>
      p.id.toString() === id
        ? { ...p, comments: [...p.comments, newComment] }
        : p
    );

    setPosts(updatedPosts);
    setCommentText("");
  };

  return (
    <main className="content-container">
      <div className="content-box post-detail-section">
        {/* Post Detail */}
        <button className="back-btn" onClick={() => navigate('/forum')}>
          ← Back to Forum
        </button>
        <h2 className="post-title-detail">{post.title}</h2>
        <p className="post-meta">By {post.author}</p>
        <div className="post-content">
          {/* Using dangerouslySetInnerHTML for content, assuming the content is sanitized elsewhere */}
          <p>{post.content}</p> 
        </div>

        <hr className="post-divider"/>

        {/* Comment Section */}
        <h3 className="comments-header">Comments ({post.comments.length})</h3>

        {/* Comment List */}
        <div className="comment-list">
          {post.comments.length === 0 ? (
            <p style={{ opacity: 0.7 }}>No comments yet. Be the first to start a discussion!</p>
          ) : (
            post.comments.slice().reverse().map((comment) => ( // Reverse to show latest first
              <div key={comment.id} className="comment-item">
                <p className="comment-author">{comment.author} <span className="comment-date">({comment.date})</span></p>
                <p className="comment-text">{comment.text}</p>
              </div>
            ))
          )}
        </div>

        {/* Comment Form */}
        <form onSubmit={handleCommentSubmit} className="comment-form">
          <textarea
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            placeholder={user ? "Write your comment..." : "You must be logged in to comment."}
            disabled={!user}
            rows="4"
          />
          <button type="submit" className="tierlist-btn" disabled={!user}>
            Submit Comment
          </button>
        </form>
      </div>
    </main>
  );
}