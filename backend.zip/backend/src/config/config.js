import dotenv from "dotenv";
dotenv.config();

export default {
  development: {
    username: process.env.PG_USER,
    password: process.env.PG_PASS,
    database: process.env.PG_NAME,
    host: process.env.PG_HOST,
    dialect: "mysql",
  },
};
