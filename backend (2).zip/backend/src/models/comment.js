export default (sequelize, DataTypes) => {
  return sequelize.define("Comment", {
    comment_id: { // Sesuai SQL
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    content: { type: DataTypes.TEXT, allowNull: false }
    // post_id akan ditangani oleh relasi di index.js
  }, {
    tableName: 'comments',
    timestamps: true
  });
};